#pragma once

#define WIN32_LEAN_AND_MEAN

#include <Windows.h>
#include <jni.h>

#include <iostream>
#include <string>

#include "java/a_class.h"
#include "java/b_class.h"
#include "java/c_class.h"
#include "java/d_class.h"

#include "java/util/j_util.h"

#include "srg/srg.h"

#include "memory.h"

#include "zip/zip.h"

#include "resources/resources.h"
#include "resource.h"

