#include "resources.h"

void Resources::Init(HINSTANCE handle)
{
	this->handle = handle;
}

HINSTANCE GetHandle() {
	static int s_somevar = 0;
	MEMORY_BASIC_INFORMATION mbi;
	if (!::VirtualQuery(&s_somevar, &mbi, sizeof(mbi)))
	{
		return NULL;
	}
	return static_cast<HINSTANCE>(mbi.AllocationBase);
}

void* Resources::Load(int id, size_t* size)
{
	HINSTANCE handle = GetHandle();
	if (handle == NULL)
		printf("[Resources] Handle is null\n");
	HRSRC res = NULL;
	HGLOBAL resHandle = NULL;
	void* resData = NULL;
	DWORD resSize = 0;

	if (size)
		*size = resSize;

	if ((res = FindResource(handle, MAKEINTRESOURCE(id), L"BINARY")))
	{
		if ((resHandle = LoadResource(handle, res)))
		{
			resData = LockResource(resHandle);

			if (NULL != resData)
			{
				if (size)
					*size = SizeofResource(handle, res);
			}
			else {
				printf("res data is null\n");
			}
		}
		else {
			printf("load resource failed\n");
		}
	}
	else {
		printf("res is null\n");
	}

	return resData;
}

Resources resources;