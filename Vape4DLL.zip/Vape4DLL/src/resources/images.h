#pragma once

#include <string>
#include <map>
#include <iostream>
#include "resources.h"

class Images
{
public:
	typedef struct {
		size_t size;
		char* contents;
	} image;
private:
	bool initialized;
	std::map<std::string, image> image_table;
private:
	auto Init() -> void;
public:
	void Load();
	image GetImage(std::string name);
};
extern Images images;