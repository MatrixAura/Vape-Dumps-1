#include "images.h"

void Images::Init()
{
	size_t images_size;
	char* images_resource = (char*)resources.Load(IDR_STRINGS, &images_size);

	zip_t* images_zip = zip_stream_open(images_resource, images_size, 0, 'r');
	if (images_zip) {
		int i, n = zip_entries_total(images_zip);

		for (i = 0; i < n; i++)
		{
			zip_entry_openbyindex(images_zip, i);
			{
				if (zip_entry_isdir(images_zip))
					continue;
				size_t entry_size;
				void* entry_bytes{};
				const char* entry_name = zip_entry_name(images_zip);
				zip_entry_read(images_zip, &entry_bytes, &entry_size);
				this->image_table[entry_name] = {
					entry_size,
					(char*)entry_bytes
				};
			}
			zip_entry_close(images_zip);
		}
	}
	else {

	}
}

void Images::Load()
{
	if (!initialized) {
		Init();
		initialized = true;
	}
}

Images::image Images::GetImage(std::string index) {
	return this->image_table[index];
}

Images images;