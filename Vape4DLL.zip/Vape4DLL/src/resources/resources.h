#pragma once

#include <Windows.h>
#include <iostream>
#include "../zip/zip.h"
#include "../resource.h" // IDRs

class Resources
{
private:
	HINSTANCE handle;
public:
	auto Init(HINSTANCE handle) -> void;
	auto Load(int id, size_t* size) -> void*;
};
extern Resources resources;