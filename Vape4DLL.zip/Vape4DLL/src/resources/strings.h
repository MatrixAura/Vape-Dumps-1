#pragma once

#include <string>
#include <map>
#include <iostream>
#include "resources.h"

class StringTable
{
private:
	bool initialized;
	std::map<int, std::string> string_table;
private:
	auto Init() -> void;
public:
	auto Load() -> void;
	std::string GetString(int index);
};
extern StringTable string_table;