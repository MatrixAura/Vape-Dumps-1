#include "strings.h"

void StringTable::Init()
{
	size_t strings_size;
	char* string_resource = (char*)resources.Load(IDR_STRINGS, &strings_size);

	zip_t* strings_zip = zip_stream_open(string_resource, strings_size, 0, 'r');
	if (strings_zip) {
		int i, n = zip_entries_total(strings_zip);
		for (i = 0; i < n; i++)
		{
			zip_entry_openbyindex(strings_zip, i);
			{
				if (zip_entry_isdir(strings_zip))
					continue;
				size_t entry_size;
				void* entry_bytes{};
				const char* entry_name = zip_entry_name(strings_zip);
				zip_entry_read(strings_zip, &entry_bytes, &entry_size);
				int id = std::stoi(entry_name);
				std::string contents = std::string((char*)entry_bytes);
				this->string_table[id] = contents;
			}
			zip_entry_close(strings_zip);
		}
	}
}

void StringTable::Load()
{
	if (!initialized) {
		Init();
		initialized = true;
	}
}

std::string StringTable::GetString(int index) {
	return this->string_table[index];
}

StringTable string_table;