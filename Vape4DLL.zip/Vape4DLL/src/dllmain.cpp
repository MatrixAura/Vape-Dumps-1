// dllmain.cpp : Defines the entry point for the DLL application.

#pragma warning(disable:4996)
#include "dllmain.h"
#include <WinSock2.h>

VOID RegisterVapeNatives(JNIEnv* env, jclass cls, JNINativeMethod methods[], int size) {
	int error;
	if ((error = env->RegisterNatives(cls, methods, size)) < 0) {
		printf("Failed to register %i native methods for '%s'\n", size, GetInternalClassName(env, cls));
	}
	else {
		printf("Registered %i native methods for '%s'\n", size, GetInternalClassName(env, cls));
	}
}

using namespace std;

jint GetForgeMinorVersion(JNIEnv* env, jclass clsForgeVersion) {
	jfieldID fidMinorVersion = env->GetStaticFieldID(clsForgeVersion, "minorVersion", "I");
	return env->GetStaticIntField(clsForgeVersion, fidMinorVersion);
}

jobject GetMinecraftClassLoader(JNIEnv* env) {
}

int GetMinecraftVersion(JNIEnv* env) {
	jclass clsForgeVersion = env->FindClass("net/minecraftforge/common/ForgeVersion");
	if (env->ExceptionCheck()) {

	}
	if (clsForgeVersion != NULL) {
		return GetForgeMinorVersion(env, clsForgeVersion);
	}
	else {
		jclass clsObject = env->FindClass("java/lang/Object");
		jmethodID midToString = env->GetMethodID(clsObject, "toString", "Ljava/lang/String;");
		jclass clsMain = env->FindClass("net/minecraft/client/main/Main");
	}
}

typedef struct APP_CTX {
	JavaVM* jvm;
	JNIEnv* jniEnv;
} APP_CTX, * PAPP_CTX;


// copied from DLL
jobject GetClassLoader(JNIEnv* env) {
	jclass clsSecureClassLoader;
	jmethodID midSecureClassLoaderInit;
	jobject objLoader;

	jobject minecraftLoader = GetMinecraftClassLoader(env);

	clsSecureClassLoader = env->FindClass("java/security/SecureClassLoader");
	midSecureClassLoaderInit = env->GetMethodID(clsSecureClassLoader, "<init>", "(Ljava/lang/ClassLoader;)V");
	objLoader = env->NewObject(clsSecureClassLoader, midSecureClassLoaderInit);

	env->DeleteLocalRef(minecraftLoader);

	return env->NewWeakGlobalRef(objLoader);
}

VOID LoadJar(PAPP_CTX appCtx)
{

	srg.Load("1.8.9");

	JNIEnv* env = appCtx->jniEnv;

	env->PushLocalFrame(100);

	jclass clsVapeA;
	jclass clsVapeB;
	jclass clsVapeC;
	jclass clsVapeD;

	void* buffer{};
	size_t buffersize;

	jobject classLoader = GetClassLoader(env);

	size_t jarSize;
	char* jarResource = (char*)resources.Load(IDR_JAR, &jarSize);

	struct zip_t* zip = zip_stream_open((char*)jarResource, jarSize, 0, 'r');
	{
		int i, n = zip_entries_total(zip);

		for (i = 0; i < n; i++)
		{
			zip_entry_openbyindex(zip, i);
			{
				if (zip_entry_isdir(zip))
					continue;

				size_t entry_size;
				void* entry_bytes{};
				const char* entry_name = zip_entry_name(zip);
				zip_entry_read(zip, &entry_bytes, &entry_size);
				
				std::string class_name(entry_name);
				class_name.erase(class_name.end() - 6, class_name.end());
				entry_name = class_name.c_str();

				jclass classLoaderCls = env->GetObjectClass(classLoader);
				jmethodID mid_defineClass = env->GetMethodID(classLoaderCls, "defineClass", "([BII)Ljava/lang/Class;");
				jbyteArray clsBytes = env->NewByteArray(entry_size / sizeof(jbyte));
				jint clsBytesLen = env->GetArrayLength(clsBytes);

				std::cout << "Defining class: " << entry_name << " Length: " << clsBytesLen << " classloader: " << GetInternalClassName(env, classLoaderCls) << std::endl;
				jobject objClass = env->CallObjectMethod(classLoader, mid_defineClass, clsBytes, 0, clsBytesLen);

				if (objClass == nullptr) {
					std::cout << "Failed to define class: " << entry_name << std::endl;
				}
			}
			zip_entry_close(zip);
		}
	}
	zip_close(zip);

	clsVapeA = env->FindClass("a/a");
	clsVapeB = env->FindClass("a/b");
	clsVapeC = env->FindClass("a/c");
	clsVapeD = env->FindClass("a/d");

	env->DeleteWeakGlobalRef(classLoader);

	RegisterVapeNatives(env, clsVapeA, a_natives, sizeof(a_natives) / sizeof(a_natives[0]));
	RegisterVapeNatives(env, clsVapeB, b_natives, sizeof(b_natives) / sizeof(b_natives[0]));
	RegisterVapeNatives(env, clsVapeC, c_natives, sizeof(c_natives) / sizeof(c_natives[0]));
	RegisterVapeNatives(env, clsVapeD, d_natives, sizeof(d_natives) / sizeof(d_natives[0]));

	jmethodID midStart = env->GetStaticMethodID(clsVapeA, "start", "()V");

	env->PopLocalFrame(0);

	env->CallStaticVoidMethod(clsVapeA, midStart);
}

BOOL AttemptAttachJvm(PAPP_CTX appCtx)
{
	HMODULE jvmHandle;

	if (NULL != (jvmHandle = GetModuleHandle(L"jvm.dll"))) {
		typedef jint(JNICALL* fnJNI_GetCreatedJavaVMs)(JavaVM**, jsize, jsize*);
		fnJNI_GetCreatedJavaVMs JNI_GetCreatedJavaVMs = (fnJNI_GetCreatedJavaVMs)GetProcAddress(jvmHandle, "JNI_GetCreatedJavaVMs");

		if (JNI_GetCreatedJavaVMs(&appCtx->jvm, 1, NULL) == JNI_OK) {
			if ((appCtx->jvm)->AttachCurrentThread((void**)&appCtx->jniEnv, NULL) == JNI_OK) {
				return TRUE;
			}
		}
	}

	return FALSE;
}

VOID DetachJvm(PAPP_CTX appCtx) {

	if (appCtx->jvm && appCtx->jniEnv) {
		(appCtx->jvm)->DetachCurrentThread();
	}

	appCtx->jniEnv = NULL;
	appCtx->jvm = NULL;
}

VOID AttemptAttachAndDetectMinecraft()
{
	LPVOID appCtxData = MemCalloc(sizeof(APP_CTX));
	struct APP_CTX* appCtx = (struct APP_CTX*)appCtxData;

	if (NULL == appCtx)
		goto out;

	if (FALSE == AttemptAttachJvm(appCtx))
		goto out;

	LoadJar(appCtx);
out:
	DetachJvm(appCtx);
	MemFree(appCtx);
}

INT WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved) {
	if (dwReason == DLL_PROCESS_ATTACH) {
		if (AllocConsole()) {
			FILE* f;
			freopen_s(&f, "CONOUT$", "w", stdout);
			SetConsoleTitle(L"Vape DLL");
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_RED);
		}

		AttemptAttachAndDetectMinecraft();
		MemFree(lpReserved);
		FreeLibrary(hInstance);
	}

	return 0;
}
