#pragma once

#include <jni.h>
#include <Windows.h>
#include <iostream>

#include "../resources/strings.h"
#include "../resources/images.h"
#include "../dllmain.h"
#include "util/j_util.h"

/**
* Exits Vape
*/
void Exit(JNIEnv* env, jclass caller, jboolean s);

/**
* Sends a callback to the Discord Rich Presence
*/
void DiscordCallback(JNIEnv* env, jclass caller);

/**
 * 
 */
void FS(JNIEnv* env, jclass caller);

jclass GetClass(JNIEnv* env, jclass caller, jstring name);

/*
 * Full PNG File, with header.
 */
jbyteArray GetTexture(JNIEnv* env, jclass caller, jstring name);

/*
 * XOR Key for texture decryption. 0 = No difference.
*/
jint GetKey(JNIEnv* env, jclass caller);

jstring GetSettings(JNIEnv* env, jclass caller);

void SendSettings(JNIEnv* env, jclass caller, jstring string);

void MB(JNIEnv* env, jclass caller, jint code);

jclass GetClassJava(JNIEnv* env, jclass caller, jstring name);

jstring GetClassString(JNIEnv* env, jclass caller, jclass cls);

jstring CopyString(JNIEnv* env, jclass caller, jint index);

void Reload(JNIEnv* env, jclass caller);

jobject GetRHandle(JNIEnv* env, jclass caller);

void ClipboardCopy(JNIEnv* env, jclass caller, jstring string);

/**
* Prints a message to the debug console.
*/
void Print(JNIEnv* env, jclass caller, jstring string);

jshort n_GetKeyState(JNIEnv* env, jclass caller, jint i);

/**
* Gets a class's objects. (could be the weird object definitions with random strings.)
*/
jobjectArray GetClassObjects(JNIEnv* env, jclass caller, jclass cls);

jdoubleArray TRN(JNIEnv* env, jclass caller, jdouble first, jdouble second, jdouble third);

/**
* Gets a class's bytes.
*/
jbyteArray GetClassBytes(JNIEnv* env, jclass caller, jclass cls);

/**
* Sets a class's bytes.
*/
jint SetClassBytes(JNIEnv* env, jclass caller, jclass cls, jbooleanArray bytes);

/**
* Gets the {java/lang/reflect/Field} fields of a class.
*/
jobjectArray GetClassFields(JNIEnv* env, jclass caller, jclass cls);

/**
* Gets the {java/lang/reflect/Method} methods of a class.
*/
jobjectArray GetClassMethods(JNIEnv* env, jclass caller, jclass cls);

/**
* Draws a string on screen using the OpenGL context from the Minecraft window.
*/
jint DrawString(JNIEnv* env, jclass caller, jint size, jstring string, jdouble x, jdouble y, jint color);

jdouble GetStringWidth(JNIEnv* env, jclass caller, jint size, jstring string);

jdouble GetStringHeight(JNIEnv* env, jclass caller, jint size, jstring string);

void SendMouseDown(JNIEnv* env, jclass caller, jint var0, jint var1);

jstring GetProfile(JNIEnv* env, jclass caller, jstring string);

void SetUsername(JNIEnv* env, jclass caller, jstring string);

jboolean IsVanilla(JNIEnv* env, jclass caller);

jclass GetVanillaClass(JNIEnv* env, jclass caller, jstring string);

/**
* Gets the Minor version of the client.
*/
jint GetMinorVersion(JNIEnv* env, jclass caller);

void RSC(JNIEnv* env, jclass caller);

jint MakeFont(JNIEnv* env, jclass caller, jint var1, jint var2, jstring var3);

void UpdateDiscord(JNIEnv* env, jclass caller, jstring title, jstring subtitle);

jint DrawStringV2(JNIEnv* env, jclass caller, jint size, jstring string, jdouble x, jdouble y, jint color, jfloat f);

jdouble GetStringWidthV2(JNIEnv* env, jclass caller, jint size, jstring string);

jdouble GetStringHeightV2(JNIEnv* env, jclass caller, jint size, jstring string);

jint MakeFontV2(JNIEnv* env, jclass caller, jint var1, jint var2, jstring var3);

static JNINativeMethod a_natives[] = {
	{ (CHAR*)"exit",  (CHAR*)"(Z)V",									(void*)Exit },
	{ (CHAR*)"dc",    (CHAR*)"()V",										(void*)DiscordCallback },
	{ (CHAR*)"fs",    (CHAR*)"()V",										(void*)FS },
	{ (CHAR*)"gc",    (CHAR*)"(Ljava/lang/String;)Ljava/lang/Class;",	(void*)GetClass },
	{ (CHAR*)"gt",    (CHAR*)"(Ljava/lang/String;)[B",					(void*)GetTexture },
	{ (CHAR*)"gk",    (CHAR*)"()I",										(void*)GetKey },
	{ (CHAR*)"gs",    (CHAR*)"()Ljava/lang/String;",					(void*)GetSettings },
	{ (CHAR*)"ss",    (CHAR*)"(Ljava/lang/String;)V",					(void*)SendSettings },
	{ (CHAR*)"mb",    (CHAR*)"(I)V",									(void*)MB },
	{ (CHAR*)"gcj",   (CHAR*)"(Ljava/lang/String;)Ljava/lang/Class;",	(void*)GetClassJava },
	{ (CHAR*)"gcs",   (CHAR*)"(Ljava/lang/Class;)Ljava/lang/String;",	(void*)GetClassString },
	{ (CHAR*)"cs",    (CHAR*)"(I)Ljava/lang/String;",					(void*)CopyString },
	{ (CHAR*)"rl",    (CHAR*)"()V",										(void*)Reload },
	{ (CHAR*)"grh",   (CHAR*)"()Ljava/lang/Object;",					(void*)GetRHandle },
	{ (CHAR*)"cpy",   (CHAR*)"(Ljava/lang/String;)V",					(void*)ClipboardCopy },
	{ (CHAR*)"p",     (CHAR*)"(Ljava/lang/String;)V",					(void*)Print },
	{ (CHAR*)"gks",   (CHAR*)"(I)S",									(void*)n_GetKeyState },
	{ (CHAR*)"gco",   (CHAR*)"(Ljava/lang/Class;)[Ljava/lang/Object;",	(void*)GetClassObjects },
	{ (CHAR*)"trn",   (CHAR*)"(DDD)[D",									(void*)TRN },
	{ (CHAR*)"gcb",   (CHAR*)"(Ljava/lang/Class;)[B",					(void*)GetClassBytes },
	{ (CHAR*)"scb",   (CHAR*)"(Ljava/lang/Class;[B)I",					(void*)SetClassBytes },
	{ (CHAR*)"gcf",   (CHAR*)"(Ljava/lang/Class;)[Ljava/lang/String;",	(void*)GetClassFields },
	{ (CHAR*)"gcm",   (CHAR*)"(Ljava/lang/Class;)[Ljava/lang/String;",	(void*)GetClassMethods },
	{ (CHAR*)"ds",    (CHAR*)"(ILjava/lang/String;DDI)I",				(void*)DrawString },
	{ (CHAR*)"gsw",   (CHAR*)"(ILjava/lang/String;)D",					(void*)GetStringWidth },
	{ (CHAR*)"gsh",   (CHAR*)"(ILjava/lang/String;)D",					(void*)GetStringHeight },
	{ (CHAR*)"smd",   (CHAR*)"(II)V",									(void*)SendMouseDown },
	{ (CHAR*)"gp",    (CHAR*)"(Ljava/lang/String;)Ljava/lang/String;",	(void*)GetProfile },
	{ (CHAR*)"su",    (CHAR*)"(Ljava/lang/String;)V",					(void*)SetUsername },
	{ (CHAR*)"iv",    (CHAR*)"()Z",										(void*)IsVanilla },
	{ (CHAR*)"gvc",   (CHAR*)"(Ljava/lang/String;)Ljava/lang/Class;",	(void*)GetVanillaClass },
	{ (CHAR*)"gmv",   (CHAR*)"()I",										(void*)GetMinorVersion },
	{ (CHAR*)"rsc",   (CHAR*)"()V",										(void*)RSC },
	{ (CHAR*)"mf",    (CHAR*)"(IILjava/lang/String;)I",					(void*)MakeFont },
	{ (CHAR*)"updc",  (CHAR*)"(Ljava/lang/String;Ljava/lang/String;)V",	(void*)UpdateDiscord },
	{ (CHAR*)"dsv2",  (CHAR*)"(ILjava/lang/String;DDIF)I",				(void*)DrawStringV2 },
	{ (CHAR*)"gswv2", (CHAR*)"(ILjava/lang/String;)D",					(void*)GetStringWidthV2 },
	{ (CHAR*)"gshv2", (CHAR*)"(ILjava/lang/String;)D",					(void*)GetStringHeightV2 },
	{ (CHAR*)"mfv2",  (CHAR*)"(IILjava/lang/String;)I",					(void*)MakeFontV2 },
};