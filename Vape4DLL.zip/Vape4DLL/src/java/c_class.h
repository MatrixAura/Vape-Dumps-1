#pragma once

#include <jni.h>
#include <Windows.h>

/**
* Register an event in Forge for the corresponding minecraft version at the busID.
*/
void RegisterEvent(JNIEnv* env, jclass caller, jclass clazz, jint busID);

static JNINativeMethod c_natives[] = {
	{ (CHAR*)"reg", (CHAR*)"(Ljava/lang/Class;I)V", (void*)RegisterEvent }
};
