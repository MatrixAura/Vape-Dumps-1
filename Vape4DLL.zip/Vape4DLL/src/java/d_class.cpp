#include "d_class.h"

jobject obj;

jobject GetGuiObject(JNIEnv* env, jclass caller) {
	if (obj == NULL) {

		static jclass cls_class_loader = env->FindClass("java/lang/ClassLoader");
		static jmethodID mid_define_class = env->GetMethodID(cls_class_loader, "defineClass", "([BII)Ljava/lang/Class;");
		static const char* extendType = "net/minecraft/client/gui/GuiScreen";

		// 
		// 
		// net/minecraft/client/gui/GuiScreen

		jclass cls = env->FindClass("e");
		jmethodID mid = env->GetMethodID(cls, "<init>", "e");
		obj = env->CallObjectMethod(cls, mid);
	}
	return obj;
}