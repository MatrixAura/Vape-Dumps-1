#include "a_class.h"

using namespace std;

void Exit(JNIEnv* env, jclass caller, jboolean s) {

}

void DiscordCallback(JNIEnv* env, jclass caller) {

}

void FS(JNIEnv* env, jclass caller) {

}

// Class.forName(name.replace('/', '.'));
jclass GetClass(JNIEnv* env, jclass caller, jstring name) {
	const char* className = env->GetStringUTFChars(name, NULL);
	return env->FindClass(className);
}

// todo
jbyteArray GetTexture(JNIEnv* env, jclass caller, jstring name) {
	Images::image image = images.GetImage(GetString(env, name));
	jbyteArray arr = env->NewByteArray(image.size / sizeof(char));
	env->SetByteArrayRegion(arr, 0, env->GetArrayLength(arr), (const jbyte*)image.contents);
	return arr;
}

// the XOR key for image resources.
jint GetKey(JNIEnv* env, jclass caller) {
	return 0;
}

jstring GetSettings(JNIEnv* env, jclass caller) {
	// JSON base base64
	return env->NewStringUTF("e30");
}

// todo save settings to file.
void SendSettings(JNIEnv* env, jclass caller, jstring string) {

}

// settings
void MB(JNIEnv* env, jclass caller, jint code) {

}

/*
		if (name.startsWith("[")) {
			return Class.forName(name.substring(1).replace('/', '.'));
		}
		return Class.forName(Type.getType(name).getClassName());
*/
jclass GetClassJava(JNIEnv* env, jclass caller, jstring name) {

	const char* charName = env->GetStringUTFChars(name, NULL);
	std::string strName(charName);
	env->ReleaseStringUTFChars(name, charName);

	std::cout << "[CLASS] Getting class: " << strName << std::endl;

	/*if (strName.at(0) == '[') {
		strName = strName.substr(1);
		return env->FindClass(strName.c_str());
	}
	else {
	}*/
	return env->FindClass(strName.c_str());
}

// return Type.getType(cls).getInternalName();
jstring GetClassString(JNIEnv* env, jclass caller, jclass cls) {
	string className = GetInternalClassName(env, cls);
	className = GetInternalName(className);
	std::cout << "[CLASS] Getting internal class name for: " << className << std::endl;
	return env->NewStringUTF(className.c_str());
}

jstring CopyString(JNIEnv* env, jclass caller, jint index) {
	string_table.Load();
	std::string s = string_table.GetString((int)index);
	std::cout << "[STRING] Getting string at index " << index << " (" << s << ")" << std::endl;
	return env->NewStringUTF(s.c_str());
}

void Reload(JNIEnv* env, jclass caller) {

}

jobject GetRHandle(JNIEnv* env, jclass caller) {
	jclass clsObject = env->FindClass("java/lang/Object");
	jmethodID midInit = env->GetMethodID(clsObject, "<init>", "Ljava/lang/Object;");
	return env->NewObject(clsObject, midInit);
}

void ClipboardCopy(JNIEnv* env, jclass caller, jstring string) {
	std::string s = GetString(env, string);
	OpenClipboard(0);
	EmptyClipboard();
	HGLOBAL hg = GlobalAlloc(GMEM_MOVEABLE, s.size() + 1);
	if (!hg) {
		CloseClipboard();
		return;
	}
	memcpy(GlobalLock(hg), s.c_str(), s.size() + 1);
	GlobalUnlock(hg);
	SetClipboardData(CF_TEXT, hg);
	CloseClipboard();
	GlobalFree(hg);
}

void Print(JNIEnv* env, jclass caller, jstring string) {
	std::cout << GetString(env, string) << std::endl;
}

jshort n_GetKeyState(JNIEnv* env, jclass caller, jint key) {
	if (FindWindowA("LWJGL", nullptr) == GetForegroundWindow()) {
		return GetKeyState(key);
	}
	return 0;
}

jobjectArray GetClassObjects(JNIEnv* env, jclass caller, jclass cls) {
	jclass clsObject = env->FindClass("java/lang/Object");
	return env->NewObjectArray(0, clsObject, NULL);
}

// todo figure out what sort of geometric magic this does to render arrows
jdoubleArray TRN(JNIEnv* env, jclass caller, jdouble first, jdouble second, jdouble third) {
	return env->NewDoubleArray(3);
}

// not really needed.
jbyteArray GetClassBytes(JNIEnv* env, jclass caller, jclass cls) {
	return env->NewByteArray(0);
}

// not really needed
jint SetClassBytes(JNIEnv* env, jclass caller, jclass cls, jbooleanArray bytes) {
	return 0;
}

jobjectArray GetClassFields(JNIEnv* env, jclass caller, jclass cls) {
	jclass clsString = env->FindClass("java/lang/String");
	return env->NewObjectArray(0, clsString, NULL);
}

jobjectArray GetClassMethods(JNIEnv* env, jclass caller, jclass cls) {
	jclass clsString = env->FindClass("java/lang/String");
	return env->NewObjectArray(0, clsString, NULL);
}

// todo hook wglSwapBuffers, use freetype to draw font. 
jint DrawString(JNIEnv* env, jclass caller, jint size, jstring string, jdouble x, jdouble y, jint color) {
	return 0;
}

// may be GetScreenWidth, need to test.
jdouble GetStringWidth(JNIEnv* env, jclass caller, jint size, jstring string) {
	return 0;
}

// may be GetScreenHeight, need to test.
jdouble GetStringHeight(JNIEnv* env, jclass caller, jint size, jstring string) {
	return 0;
}

// most likely don't need to find the window, but hey, also GetForegroundWindow() may not be correct.
void SendMouseDown(JNIEnv* env, jclass caller, jint var0, jint var1) {
	if (FindWindow((L"LWJGL"), nullptr) == GetForegroundWindow()) {
		PostMessage(GetForegroundWindow(), var1, var0, NULL);
	}
}

// GetProfiles? 
jstring GetProfile(JNIEnv* env, jclass caller, jstring string) {
	return env->NewStringUTF("{}");
}

// Sends the Minecraft username to the DLL
// Do the funny? <keep list of users??>
void SetUsername(JNIEnv* env, jclass caller, jstring string) {

}

// Gets LaunchWrapper stuff if set to false
// Also registers Forge events etc.
jboolean IsVanilla(JNIEnv* env, jclass caller) {
	static bool isVanilla = env->FindClass("net/minecraftforge/common/ForgeVersion") == NULL;
	static bool checked;
	if (isVanilla) {
		if (!checked && env->ExceptionCheck() == JNI_TRUE) {
			env->ExceptionClear();
			checked = true;
		}
		return true;
	}
	return false;
}

jclass GetVanillaClass(JNIEnv* env, jclass caller, jstring string) {
	std::string className = GetString(env, string);
	jclass cls = env->FindClass(className.c_str());
	if (env->ExceptionCheck()) {
		cls = nullptr;
		env->ExceptionClear();
	}
	return cls;
}

// 13 (1.7), 15 (1.8), 23 (1.12)
jint GetMinorVersion(JNIEnv* env, jclass caller) {
	return 15;//GetForgeMinorVersion(env);
}


void RSC(JNIEnv* env, jclass caller) {

}

jint MakeFont(JNIEnv* env, jclass caller, jint var1, jint var2, jstring var3) {
	return 0;
}

void UpdateDiscord(JNIEnv* env, jclass caller, jstring title, jstring subtitle) {

}

jint DrawStringV2(JNIEnv* env, jclass caller, jint size, jstring string, jdouble x, jdouble y, jint color, jfloat f) {
	return 0;
}

jdouble GetStringWidthV2(JNIEnv* env, jclass caller, jint size, jstring string) {
	return 0;
}

jdouble GetStringHeightV2(JNIEnv* env, jclass caller, jint size, jstring string) {
	return 0;
}

jint MakeFontV2(JNIEnv* env, jclass caller, jint var1, jint var2, jstring var3) {
	return 0;
}