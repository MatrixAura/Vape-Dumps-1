#pragma once

#include <jni.h>
#include <Windows.h>

void GetMinecraftMethod(JNIEnv* env, jclass caller, jint id, jclass cls, jstring name, jstring desc, jboolean remap);

void GetMethod(JNIEnv* env, jclass caller, jint id, jclass cls, jstring name, jstring desc, jboolean remap);

void InvokeMethodVoid(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params);

jboolean InvokeMethodBoolean(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params);

jchar InvokeMethodChar(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params);

jshort InvokeMethodShort(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params);

jint InvokeMethodInt(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params);

jlong InvokeMethodLong(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params);

jfloat InvokeMethodFloat(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params);

jdouble InvokeMethodDouble(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params);

jobject InvokeMethodObject(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params);

jbooleanArray InvokeMethodBooleanArray(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params);

jcharArray InvokeMethodCharArray(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params);

jshortArray InvokeMethodShortArray(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params);

jintArray InvokeMethodIntArray(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params);

jlongArray InvokeMethodLongArray(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params);

jfloatArray InvokeMethodFloatArray(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params);

jdoubleArray InvokeMethodDoubleArray(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params);

jobjectArray InvokeMethodObjectArray(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params);

void GetMinecraftField(JNIEnv* env, jclass caller, jint id, jclass cls, jstring name, jstring desc, jboolean remap);

void GetField(JNIEnv* env, jclass caller, jint id, jclass cls, jstring name, jstring desc, jboolean remap);

jboolean GetFieldBoolean(JNIEnv* env, jclass caller, jint id, jobject instance);

jchar GetFieldChar(JNIEnv* env, jclass caller, jint id, jobject instance);

jshort GetFieldShort(JNIEnv* env, jclass caller, jint id, jobject instance);

jint GetFieldInt(JNIEnv* env, jclass caller, jint id, jobject instance);

jlong GetFieldLong(JNIEnv* env, jclass caller, jint id, jobject instance);

jfloat GetFieldFloat(JNIEnv* env, jclass caller, jint id, jobject instance);

jdouble GetFieldDouble(JNIEnv* env, jclass caller, jint id, jobject instance);

jobject GetFieldObject(JNIEnv* env, jclass caller, jint id, jobject instance);

jbooleanArray GetFieldBooleanArray(JNIEnv* env, jclass caller, jint id, jobject instance);

jcharArray GetFieldCharArray(JNIEnv* env, jclass caller, jint id, jobject instance);

jshortArray GetFieldShortArray(JNIEnv* env, jclass caller, jint id, jobject instance);

jintArray GetFieldIntArray(JNIEnv* env, jclass caller, jint id, jobject instance);

jlongArray GetFieldLongArray(JNIEnv* env, jclass caller, jint id, jobject instance);

jfloatArray GetFieldFloatArray(JNIEnv* env, jclass caller, jint id, jobject instance);

jdoubleArray GetFieldDoubleArray(JNIEnv* env, jclass caller, jint id, jobject instance);

jobjectArray GetFieldObjectArray(JNIEnv* env, jclass caller, jint id, jobject instance);

void SetFieldBoolean(JNIEnv* env, jclass caller, jint id, jobject instance, jboolean value);

void SetFieldChar(JNIEnv* env, jclass caller, jint id, jobject instance, jchar value);

void SetFieldShort(JNIEnv* env, jclass caller, jint id, jobject instance, jshort value);

void SetFieldInt(JNIEnv* env, jclass caller, jint id, jobject instance, jint value);

void SetFieldLong(JNIEnv* env, jclass caller, jint id, jobject instance, jlong value);

void SetFieldFloat(JNIEnv* env, jclass caller, jint id, jobject instance, jfloat value);

void SetFieldDouble(JNIEnv* env, jclass caller, jint id, jobject instance, jdouble value);

void SetFieldObject(JNIEnv* env, jclass caller, jint id, jobject instance, jobject value);

void SetFieldBooleanArray(JNIEnv* env, jclass caller, jint id, jobject instance, jbooleanArray value);

void SetFieldCharArray(JNIEnv* env, jclass caller, jint id, jobject instance, jcharArray value);

void SetFieldShortArray(JNIEnv* env, jclass caller, jint id, jobject instance, jshortArray value);

void SetFieldIntArray(JNIEnv* env, jclass caller, jint id, jobject instance, jintArray value);

void SetFieldLongArray(JNIEnv* env, jclass caller, jint id, jobject instance, jlongArray value);

void SetFieldFloatArray(JNIEnv* env, jclass caller, jint id, jobject instance, jfloatArray value);

void SetFieldDoubleArray(JNIEnv* env, jclass caller, jint id, jobject instance, jdoubleArray value);

void SetFieldObjectArray(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray value);

// a/b#bbb
void UnknownInvoke(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray value);

jobject InvokeConstructor(JNIEnv* env, jclass caller, jint id, jclass cls, jobjectArray params);

jbyte InvokeMethodByte(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params);

jbyteArray InvokeMethodByteArray(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params);

jbyte GetFieldByte(JNIEnv* env, jclass caller, jint id, jobject instance);

void SetFieldByte(JNIEnv* env, jclass caller, jint id, jobject instance, jbyte value);

jbyteArray GetFieldByteArray(JNIEnv* env, jclass caller, jint id, jobject instance);

void SetFieldByteArray(JNIEnv* env, jclass caller, jint id, jobject instance, jbyteArray value);

jstring GetFieldName(JNIEnv* env, jclass caller, jint id);

jstring GetMethodName(JNIEnv* env, jclass caller, jint id);

static JNINativeMethod b_natives[] = {
	{ (CHAR*)"a", (CHAR*)"(ILjava/lang/Class;Ljava/lang/String;Ljava/lang/String;Z)V",		(void*)GetMinecraftMethod },
	{ (CHAR*)"b", (CHAR*)"(ILjava/lang/Class;Ljava/lang/String;Ljava/lang/String;Z)V",		(void*)GetMethod },
	{ (CHAR*)"c", (CHAR*)"(ILjava/lang/Object;[Ljava/lang/Object;)V",						(void*)InvokeMethodVoid },
	{ (CHAR*)"d", (CHAR*)"(ILjava/lang/Object;[Ljava/lang/Object;)Z",						(void*)InvokeMethodBoolean },
	{ (CHAR*)"e", (CHAR*)"(ILjava/lang/Object;[Ljava/lang/Object;)C",						(void*)InvokeMethodChar },
	{ (CHAR*)"f", (CHAR*)"(ILjava/lang/Object;[Ljava/lang/Object;)S",						(void*)InvokeMethodShort },
	{ (CHAR*)"g", (CHAR*)"(ILjava/lang/Object;[Ljava/lang/Object;)I",						(void*)InvokeMethodInt },
	{ (CHAR*)"h", (CHAR*)"(ILjava/lang/Object;[Ljava/lang/Object;)J",						(void*)InvokeMethodLong },
	{ (CHAR*)"i", (CHAR*)"(ILjava/lang/Object;[Ljava/lang/Object;)F",						(void*)InvokeMethodFloat },
	{ (CHAR*)"j", (CHAR*)"(ILjava/lang/Object;[Ljava/lang/Object;)D",						(void*)InvokeMethodDouble },
	{ (CHAR*)"k", (CHAR*)"(ILjava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;",		(void*)InvokeMethodObject },
	{ (CHAR*)"l", (CHAR*)"(ILjava/lang/Object;[Ljava/lang/Object;)[Z",						(void*)InvokeMethodBooleanArray },
	{ (CHAR*)"m", (CHAR*)"(ILjava/lang/Object;[Ljava/lang/Object;)[C",						(void*)InvokeMethodCharArray },
	{ (CHAR*)"n", (CHAR*)"(ILjava/lang/Object;[Ljava/lang/Object;)[S",						(void*)InvokeMethodShortArray },
	{ (CHAR*)"o", (CHAR*)"(ILjava/lang/Object;[Ljava/lang/Object;)[I",						(void*)InvokeMethodIntArray },
	{ (CHAR*)"p", (CHAR*)"(ILjava/lang/Object;[Ljava/lang/Object;)[J",						(void*)InvokeMethodLongArray },
	{ (CHAR*)"q", (CHAR*)"(ILjava/lang/Object;[Ljava/lang/Object;)[F",						(void*)InvokeMethodFloatArray },
	{ (CHAR*)"r", (CHAR*)"(ILjava/lang/Object;[Ljava/lang/Object;)[D",						(void*)InvokeMethodDoubleArray },
	{ (CHAR*)"s", (CHAR*)"(ILjava/lang/Object;[Ljava/lang/Object;)[Ljava/lang/Object;",		(void*)InvokeMethodObjectArray },
	{ (CHAR*)"t", (CHAR*)"(ILjava/lang/Class;Ljava/lang/String;Ljava/lang/String;Z)V",		(void*)GetMinecraftField },
	{ (CHAR*)"u", (CHAR*)"(ILjava/lang/Class;Ljava/lang/String;Ljava/lang/String;Z)V",		(void*)GetField },
	{ (CHAR*)"v", (CHAR*)"(ILjava/lang/Object;)Z",											(void*)GetFieldBoolean },
	{ (CHAR*)"w", (CHAR*)"(ILjava/lang/Object;)C",											(void*)GetFieldChar },
	{ (CHAR*)"x", (CHAR*)"(ILjava/lang/Object;)S",											(void*)GetFieldShort },
	{ (CHAR*)"y", (CHAR*)"(ILjava/lang/Object;)I",											(void*)GetFieldInt },
	{ (CHAR*)"z", (CHAR*)"(ILjava/lang/Object;)J",											(void*)GetFieldLong },
	{ (CHAR*)"aa", (CHAR*)"(ILjava/lang/Object;)F",											(void*)GetFieldFloat },
	{ (CHAR*)"bb", (CHAR*)"(ILjava/lang/Object;)D",											(void*)GetFieldDouble },
	{ (CHAR*)"cc", (CHAR*)"(ILjava/lang/Object;)Ljava/lang/Object;",						(void*)GetFieldObject },
	{ (CHAR*)"dd", (CHAR*)"(ILjava/lang/Object;)[Z",										(void*)GetFieldBooleanArray },
	{ (CHAR*)"ee", (CHAR*)"(ILjava/lang/Object;)[C",										(void*)GetFieldCharArray },
	{ (CHAR*)"ff", (CHAR*)"(ILjava/lang/Object;)[S",										(void*)GetFieldShortArray },
	{ (CHAR*)"gg", (CHAR*)"(ILjava/lang/Object;)[I",										(void*)GetFieldIntArray },
	{ (CHAR*)"hh", (CHAR*)"(ILjava/lang/Object;)[J",										(void*)GetFieldLongArray },
	{ (CHAR*)"ii", (CHAR*)"(ILjava/lang/Object;)[F",										(void*)GetFieldFloatArray },
	{ (CHAR*)"jj", (CHAR*)"(ILjava/lang/Object;)[D",										(void*)GetFieldDoubleArray },
	{ (CHAR*)"kk", (CHAR*)"(ILjava/lang/Object;)[Ljava/lang/Object;",						(void*)GetFieldObjectArray },
	{ (CHAR*)"ll", (CHAR*)"(ILjava/lang/Object;Z)V",										(void*)SetFieldBoolean },
	{ (CHAR*)"mm", (CHAR*)"(ILjava/lang/Object;C)V",										(void*)SetFieldChar },
	{ (CHAR*)"nn", (CHAR*)"(ILjava/lang/Object;S)V",										(void*)SetFieldShort },
	{ (CHAR*)"oo", (CHAR*)"(ILjava/lang/Object;I)V",										(void*)SetFieldInt },
	{ (CHAR*)"pp", (CHAR*)"(ILjava/lang/Object;J)V",										(void*)SetFieldLong },
	{ (CHAR*)"qq", (CHAR*)"(ILjava/lang/Object;F)V",										(void*)SetFieldFloat },
	{ (CHAR*)"rr", (CHAR*)"(ILjava/lang/Object;D)V",										(void*)SetFieldDouble },
	{ (CHAR*)"ss", (CHAR*)"(ILjava/lang/Object;Ljava/lang/Object;)V",						(void*)SetFieldObject },
	{ (CHAR*)"tt", (CHAR*)"(ILjava/lang/Object;[Z)V",										(void*)SetFieldBooleanArray },
	{ (CHAR*)"uu", (CHAR*)"(ILjava/lang/Object;[C)V",										(void*)SetFieldCharArray },
	{ (CHAR*)"vv", (CHAR*)"(ILjava/lang/Object;[S)V",										(void*)SetFieldShortArray },
	{ (CHAR*)"ww", (CHAR*)"(ILjava/lang/Object;[I)V",										(void*)SetFieldIntArray },
	{ (CHAR*)"xx", (CHAR*)"(ILjava/lang/Object;[J)V",										(void*)SetFieldLongArray },
	{ (CHAR*)"yy", (CHAR*)"(ILjava/lang/Object;[F)V",										(void*)SetFieldFloatArray },
	{ (CHAR*)"zz", (CHAR*)"(ILjava/lang/Object;[D)V",										(void*)SetFieldDoubleArray },
	{ (CHAR*)"aaa", (CHAR*)"(ILjava/lang/Object;[Ljava/lang/Object;)V",						(void*)SetFieldObjectArray },
	{ (CHAR*)"bbb", (CHAR*)"(ILjava/lang/Object;[Ljava/lang/Object;)V",						(void*)UnknownInvoke },
	{ (CHAR*)"ccc", (CHAR*)"(ILjava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;",		(void*)InvokeConstructor },
	{ (CHAR*)"ddd", (CHAR*)"(ILjava/lang/Object;[Ljava/lang/Object;)B",						(void*)InvokeMethodByte },
	{ (CHAR*)"eee", (CHAR*)"(ILjava/lang/Object;[Ljava/lang/Object;)[B",					(void*)InvokeMethodByteArray },
	{ (CHAR*)"fff", (CHAR*)"(ILjava/lang/Object;)B",										(void*)GetFieldByte },
	{ (CHAR*)"ggg", (CHAR*)"(ILjava/lang/Object;B)V",										(void*)SetFieldByte },
	{ (CHAR*)"hhh", (CHAR*)"(ILjava/lang/Object;)[B",										(void*)GetFieldByteArray },
	{ (CHAR*)"iii", (CHAR*)"(ILjava/lang/Object;[B)V",										(void*)SetFieldByteArray },
	{ (CHAR*)"gfn", (CHAR*)"(I)Ljava/lang/String;",											(void*)GetFieldName },
	{ (CHAR*)"gmn", (CHAR*)"(I)Ljava/lang/String;",											(void*)GetMethodName }
};
