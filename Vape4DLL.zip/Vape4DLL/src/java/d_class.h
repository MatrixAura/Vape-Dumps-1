#pragma once

#include <jni.h>
#include <Windows.h>

/**
 * Gets the instance of the "e" class, which is the Native wrapper for the GUI screen.
*/
jobject GetGuiObject(JNIEnv* env, jclass caller);

static JNINativeMethod d_natives[] = {
	{(CHAR*)"getGuiObject", (CHAR*)"()Ljava/lang/Object;", (void*)GetGuiObject }
};
