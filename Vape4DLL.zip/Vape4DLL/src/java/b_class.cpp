#include "b_class.h"

#include <map>
#include <iostream>
#include <algorithm>

#include "./util/j_util.h"
#include "../srg/srg.h"

#pragma warning(disable: 4715) // disable macro warnings.

void GetTypeField(JNIEnv* jni_env, jobject obj_instance, jvalue* ptr_value)
{
	static jclass clsBoolean = jni_env->FindClass("java/lang/Boolean");
	static jclass clsChar = jni_env->FindClass("java/lang/Character");
	static jclass clsByte = jni_env->FindClass("java/lang/Byte");
	static jclass clsShort = jni_env->FindClass("java/lang/Short");
	static jclass clsInt = jni_env->FindClass("java/lang/Integer");
	static jclass clsLong = jni_env->FindClass("java/lang/Long");
	static jclass clsFloat = jni_env->FindClass("java/lang/Float");
	static jclass clsDouble = jni_env->FindClass("java/lang/Double");
	static jfieldID fidBooleanValue = jni_env->GetFieldID(clsBoolean, "value", "Z");
	static jfieldID fidCharValue = jni_env->GetFieldID(clsChar, "value", "C");
	static jfieldID fidByteValue = jni_env->GetFieldID(clsByte, "value", "B");
	static jfieldID fidShortValue = jni_env->GetFieldID(clsShort, "value", "S");
	static jfieldID fidIntValue = jni_env->GetFieldID(clsInt, "value", "I");
	static jfieldID fidLongValue = jni_env->GetFieldID(clsLong, "value", "J");
	static jfieldID fidFloatValue = jni_env->GetFieldID(clsFloat, "value", "F");
	static jfieldID fidDoubleValue = jni_env->GetFieldID(clsDouble, "value", "D");
	if (obj_instance == NULL) {
		ptr_value = NULL;
		return;
	}
	if (jni_env->IsInstanceOf(obj_instance, clsBoolean)) {
		ptr_value->z = jni_env->GetBooleanField(obj_instance, fidBooleanValue);
		return;
	}
	if (jni_env->IsInstanceOf(obj_instance, clsChar)) {
		ptr_value->c = jni_env->GetCharField(obj_instance, fidCharValue);
		return;
	}
	if (jni_env->IsInstanceOf(obj_instance, clsByte)) {
		ptr_value->b = jni_env->GetByteField(obj_instance, fidByteValue);
		return;
	}
	if (jni_env->IsInstanceOf(obj_instance, clsShort)) {
		ptr_value->s = jni_env->GetShortField(obj_instance, fidShortValue);
		return;
	}
	if (jni_env->IsInstanceOf(obj_instance, clsInt)) {
		ptr_value->i = jni_env->GetIntField(obj_instance, fidIntValue);
		return;
	}
	if (jni_env->IsInstanceOf(obj_instance, clsLong)) {
		ptr_value->j = jni_env->GetLongField(obj_instance, fidLongValue);
		return;
	}
	if (jni_env->IsInstanceOf(obj_instance, clsFloat)) {
		ptr_value->f = jni_env->GetFloatField(obj_instance, fidFloatValue);
		return;
	}
	if (jni_env->IsInstanceOf(obj_instance, clsDouble)) {
		ptr_value->d = jni_env->GetDoubleField(obj_instance, fidDoubleValue);
		return;
	}
	ptr_value->l = obj_instance;
	return;
}

jobject GetObjectArrayNative
(JNIEnv* jni_env, jclass cls_b, int id, jobject obj_instance, jarray arr)
{
	jsize length = jni_env->GetArrayLength(arr);
	jvalue* args = (jvalue*) malloc(length * sizeof(jvalue));
	int index = 0;

	jobject element;
	jvalue value;
	while (length > index) {
		element = jni_env->GetObjectArrayElement((jobjectArray)arr, index);
		GetTypeField(jni_env, element, &value);
		args[index] = value;
		index++;
	}
	//jni_env->CallObjectMethodA()
}

using namespace std;

typedef struct {
	jclass cls;
	jfieldID fid;
	jstring name;
	bool isStatic;
} field;

typedef struct {
	jclass cls;
	jmethodID mid;
	jstring name;
	bool isStatic;
} method;

typedef struct {
	jclass cls;
	jmethodID mid;
} constructor;

map<int, field> fields;
map<int, method> methods;
map<int, jclass> classes;
map<int, constructor> constructors;

#define CallMethod(staticFunc, instanceFunc, id, params, instance) {\
            if (methods.count(id))\
			{\
				method md = methods[id];\
				if (md.isStatic)\
				{\
					return staticFunc(md.cls, md.mid, params);\
				}\
				else\
				{\
					return instanceFunc(instance, md.mid, params);\
				}\
			}\
			else\
			{\
				std::cout << "Attempted to invoke method that does not exist (" << id << ")" << std::endl;\
			}\
}\


#define CallMethodCast(staticFunc, instanceFunc, id, params, instance, cast) {\
            if (methods.count(id))\
			{\
				method md = methods[id];\
				if (md.isStatic)\
				{\
					return (cast)staticFunc(md.cls, md.mid, params);\
				}\
				else\
				{\
					return (cast)instanceFunc(instance, md.mid, params);\
				}\
			}\
			else\
			{\
				std::cout << "Attempted to invoke method that does not exist (" << id << ")" << std::endl;\
			}\
}\

#define GetFieldType(staticFunc, instanceFunc, id, instance) {\
            if (fields.count(id))\
			{\
				field fd = fields[id];\
				if (fd.isStatic)\
				{\
					return staticFunc(fd.cls, fd.fid);\
				}\
				else\
				{\
					return instanceFunc(instance, fd.fid);\
				}\
			}\
			else\
			{\
				std::cout << "Attempted to get field that does not exist (" << id << ")" << std::endl;\
			}\
}\

#define GetFieldTypeCast(staticFunc, instanceFunc, id, instance, cast) {\
            if (fields.count(id))\
			{\
				field fd = fields[id];\
				if (fd.isStatic)\
				{\
					return (cast)staticFunc(fd.cls, fd.fid);\
				}\
				else\
				{\
					return (cast)instanceFunc(instance, fd.fid);\
				}\
			}\
			else\
			{\
				std::cout << "Attempted to get field that does not exist (" << id << ")" << std::endl;\
			}\
}\

#define SetFieldType(staticFunc, instanceFunc, id, instance, value) {\
            if (fields.count(id))\
			{\
				field fd = fields[id];\
				if (fd.isStatic)\
				{\
					return staticFunc(fd.cls, fd.fid, value);\
				}\
				else\
				{\
					return instanceFunc(instance, fd.fid, value);\
				}\
			}\
			else\
			{\
				std::cout << "Attempted to set field that does not exist (" << id << ")" << std::endl;\
			}\
}\

#define SetFieldTypeCast(staticFunc, instanceFunc, id, instance, value, cast) {\
            if (fields.count(id))\
			{\
				field fd = fields[id];\
				if (fd.isStatic)\
				{\
					return (cast)staticFunc(fd.cls, fd.fid, value);\
				}\
				else\
				{\
					return (cast)instanceFunc(instance, fd.fid, value);\
				}\
			}\
			else\
			{\
				std::cout << "Attempted to set field that does not exist (" << id << ")" << std::endl;\
			}\
}\

jmethodID GetMethodOr(JNIEnv* env, jclass cls, jstring mdName1, jstring mdDesc1, jstring mdName2, jstring mdDesc2, jboolean isStatic) {
	if (mdName2 != nullptr && mdDesc2 != nullptr) {

	}
	else {

	}
}

void GetMinecraftMethod(JNIEnv* env, jclass caller, jint id, jclass cls, jstring name, jstring desc, jboolean isStatic) {
	if (!methods.count(id)) {

		string mdName = GetString(env, name);
		string mdDesc = GetString(env, desc);
		string clsName = GetInternalClassName(env, cls);

		if (clsName.find("/") == string::npos && clsName.find("$") == string::npos) {
			mdName = srg.GetSRGFieldName(clsName, mdName);
			clsName = srg.GetUnobfuscatedClassName(clsName);
		}
		else if (mdName.find("func_") != string::npos) {
			mdName = srg.GetMCPMethodName(mdName);
		}


		if (mdName.find("<init>") != string::npos) {

			std::cout << "[METHOD] Getting minecraft constructor method " << mdName << " desc: " << mdDesc << " from class: " << clsName << " at id: " << id << std::endl;


			constructors[id] = {
			   (jclass)env->NewGlobalRef(cls),
				env->GetMethodID(cls, mdName.c_str(), mdDesc.c_str())
			};
			return;
		}

		if (isStatic) {
			std::cout << "[METHOD] Getting static minecraft method " << mdName << " desc: " << mdDesc << " from class: " << clsName << " at id: " << id << std::endl;

			methods[id] = {
				(jclass)env->NewGlobalRef(cls),
				env->GetStaticMethodID(cls, mdName.c_str(), mdDesc.c_str()),
				(jstring)env->NewGlobalRef(name),
				true
			};
		}
		else {
			std::cout << "[METHOD] Getting minecraft method " << mdName << " desc: " << mdDesc << " from class: " << clsName << " at id: " << id << std::endl;

			methods[id] = {
				(jclass)env->NewGlobalRef(cls),
				env->GetMethodID(cls, mdName.c_str(), mdDesc.c_str()),
				(jstring)env->NewGlobalRef(name),
				false
			};
		}
	}
	else {
		std::cout << "Attempted to get method that already exists" << std::endl;
	}
}

void GetMethod(JNIEnv* env, jclass caller, jint id, jclass cls, jstring name, jstring desc, jboolean isStatic) {
	if (!methods.count(id)) {
		string mdName = GetString(env, name);
		string mdDesc = GetString(env, desc);
		string clsName = GetInternalClassName(env, cls);

		if (mdName.find("<init>") != string::npos) {

			std::cout << "[METHOD] Getting constructor method " << mdName << " desc: " << mdDesc << " from class: " << clsName << " at id: " << id << std::endl;

			constructors[id] = {
			   (jclass)env->NewGlobalRef(cls),
				env->GetMethodID(cls, mdName.c_str(), mdDesc.c_str())
			};
			return;
		}

		if (isStatic) {
			std::cout << "[METHOD] Getting method " << mdName << " desc: " << mdDesc << " from class: " << clsName << " at id: " << id << std::endl;

			methods[id] = {
				(jclass)env->NewGlobalRef(cls),
				env->GetStaticMethodID(cls, mdName.c_str(), mdDesc.c_str()),
				(jstring)env->NewGlobalRef(name),
				true
			};
		}
		else {
			std::cout << "[METHOD] Getting method " << mdName << " desc: " << mdDesc << " from class: " << clsName << " at id: " << id << std::endl;

			methods[id] = {
				(jclass)env->NewGlobalRef(cls),
				env->GetMethodID(cls, mdName.c_str(), mdDesc.c_str()),
				(jstring)env->NewGlobalRef(name),
				false
			};
		}
	}
	else {
		std::cout << "Attempted to get method that already exists (" << id << ")" << std::endl;
	}
}

void InvokeMethodVoid(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params) {
	if (methods.count(id)) {
		method md = methods[id];
		if (md.isStatic) {
			env->CallStaticVoidMethod(md.cls, md.mid, params);
		}
		else {
			env->CallVoidMethod(instance, md.mid, params);
		}
	}
	else {
		std::cout << "Attempted to invoke method that does not exist (" << id << ")" << std::endl;
	}
}

jboolean InvokeMethodBoolean(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params) {
	CallMethod(env->CallStaticBooleanMethod, env->CallBooleanMethod, id, params, instance);
}

jchar InvokeMethodChar(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params) {
	CallMethod(env->CallStaticCharMethod, env->CallCharMethod, id, params, instance);
}

jshort InvokeMethodShort(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params) {
	CallMethod(env->CallStaticShortMethod, env->CallShortMethod, id, params, instance);
}

jint InvokeMethodInt(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params) {
	CallMethod(env->CallStaticIntMethod, env->CallIntMethod, id, params, instance);
}

jlong InvokeMethodLong(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params) {
	CallMethod(env->CallStaticLongMethod, env->CallLongMethod, id, params, instance);
}

jfloat InvokeMethodFloat(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params) {
	CallMethod(env->CallStaticFloatMethod, env->CallFloatMethod, id, params, instance);
}

jdouble InvokeMethodDouble(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params) {
	CallMethod(env->CallStaticDoubleMethod, env->CallDoubleMethod, id, params, instance);
}

jobject InvokeMethodObject(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params) {
	CallMethod(env->CallStaticObjectMethod, env->CallObjectMethod, id, params, instance);
}

jbooleanArray InvokeMethodBooleanArray(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params) {
	CallMethodCast(env->CallStaticObjectMethod, env->CallObjectMethod, id, params, instance, jbooleanArray);
}

jcharArray InvokeMethodCharArray(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params) {
	CallMethodCast(env->CallStaticObjectMethod, env->CallObjectMethod, id, params, instance, jcharArray);
}

jshortArray InvokeMethodShortArray(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params) {
	CallMethodCast(env->CallStaticObjectMethod, env->CallObjectMethod, id, params, instance, jshortArray);
}

jintArray InvokeMethodIntArray(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params) {
	CallMethodCast(env->CallStaticObjectMethod, env->CallObjectMethod, id, params, instance, jintArray);
}

jlongArray InvokeMethodLongArray(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params) {
	CallMethodCast(env->CallStaticObjectMethod, env->CallObjectMethod, id, params, instance, jlongArray);
}

jfloatArray InvokeMethodFloatArray(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params) {
	CallMethodCast(env->CallStaticObjectMethod, env->CallObjectMethod, id, params, instance, jfloatArray);
}

jdoubleArray InvokeMethodDoubleArray(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params) {
	CallMethodCast(env->CallStaticObjectMethod, env->CallObjectMethod, id, params, instance, jdoubleArray);
}

jobjectArray InvokeMethodObjectArray(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params) {
	CallMethodCast(env->CallStaticObjectMethod, env->CallObjectMethod, id, params, instance, jobjectArray);
}

void GetMinecraftField(JNIEnv* env, jclass caller, jint id, jclass cls, jstring name, jstring desc, jboolean isStatic) {
	if (!fields.count(id)) {
		string fdName = GetString(env, name);
		string fdDesc = GetString(env, desc);
		string clsName = GetInternalClassName(env, cls);

		if (clsName.find("/") == string::npos && clsName.find("$") == string::npos) {
			fdName = srg.GetSRGFieldName(clsName, fdName);
			clsName = srg.GetUnobfuscatedClassName(clsName);
		}
		else if (fdName.find("field_") != string::npos) {
			fdName = srg.GetMCPFieldName(fdName);
		}


		if (isStatic) {
			std::cout << "[FIELD] Getting static minecraft field " << fdName << " desc: " << fdDesc << " from class: " << clsName << " at id: " << id << std::endl;

			fields[id] = {
				(jclass)env->NewGlobalRef(cls),
				env->GetStaticFieldID(cls, fdName.c_str(), fdDesc.c_str()),
				(jstring)env->NewGlobalRef(name),
				true
			};
		}
		else {
			std::cout << "[FIELD] Getting minecraft field " << fdName << " desc: " << fdDesc << " from class: " << clsName << " at id: " << id << std::endl;


			fields[id] = {
				(jclass)env->NewGlobalRef(cls),
				env->GetFieldID(cls, fdName.c_str(), fdDesc.c_str()),
				(jstring)env->NewGlobalRef(name),
				false
			};
		}
	}
	else {
		std::cout << "Attempted to get field that already exists (" << id << ")" << std::endl;
	}
}

void GetField(JNIEnv* env, jclass caller, jint id, jclass cls, jstring name, jstring desc, jboolean isStatic) {
	if (!fields.count(id)) {
		string fdName = GetString(env, name);
		string fdDesc = GetString(env, desc);
		string clsName = GetInternalClassName(env, cls);


		if (isStatic) {
			std::cout << "[FIELD] Getting static field " << fdName << " desc: " << fdDesc << " from class: " << clsName << " at id: " << id << std::endl;

			fields[id] = {
				(jclass)env->NewGlobalRef(cls),
				env->GetStaticFieldID(cls, fdName.c_str(), fdDesc.c_str()),
				(jstring)env->NewGlobalRef(name),
				true
			};
		}
		else {
			std::cout << "[FIELD] Getting field " << fdName << " desc: " << fdDesc << " from class: " << clsName << " at id: " << id << std::endl;


			fields[id] = {
				(jclass)env->NewGlobalRef(cls),
				env->GetFieldID(cls, fdName.c_str(), fdDesc.c_str()),
				(jstring)env->NewGlobalRef(name),
				false
			};
		}
	}
	else {
		std::cout << "Attempted to get field that already exists (" << id << ")" << std::endl;
	}
}

jboolean GetFieldBoolean(JNIEnv* env, jclass caller, jint id, jobject instance) {
	GetFieldType(env->GetStaticBooleanField, env->GetBooleanField, id, instance);
}

jchar GetFieldChar(JNIEnv* env, jclass caller, jint id, jobject instance) {
	GetFieldType(env->GetStaticCharField, env->GetCharField, id, instance);
}


jshort GetFieldShort(JNIEnv* env, jclass caller, jint id, jobject instance) {
	GetFieldType(env->GetStaticShortField, env->GetShortField, id, instance);
}

jint GetFieldInt(JNIEnv* env, jclass caller, jint id, jobject instance) {
	GetFieldType(env->GetStaticIntField, env->GetIntField, id, instance);
}

jlong GetFieldLong(JNIEnv* env, jclass caller, jint id, jobject instance) {
	GetFieldType(env->GetStaticLongField, env->GetLongField, id, instance);
}

jfloat GetFieldFloat(JNIEnv* env, jclass caller, jint id, jobject instance) {
	GetFieldType(env->GetStaticFloatField, env->GetFloatField, id, instance);
}

jdouble GetFieldDouble(JNIEnv* env, jclass caller, jint id, jobject instance) {
	GetFieldType(env->GetStaticDoubleField, env->GetDoubleField, id, instance);
}

jobject GetFieldObject(JNIEnv* env, jclass caller, jint id, jobject instance) {
	GetFieldType(env->GetStaticObjectField, env->GetObjectField, id, instance);
}

jbooleanArray GetFieldBooleanArray(JNIEnv* env, jclass caller, jint id, jobject instance) {
	GetFieldTypeCast(env->GetStaticObjectField, env->GetObjectField, id, instance, jbooleanArray);
}

jcharArray GetFieldCharArray(JNIEnv* env, jclass caller, jint id, jobject instance) {
	GetFieldTypeCast(env->GetStaticObjectField, env->GetObjectField, id, instance, jcharArray);
}

jshortArray GetFieldShortArray(JNIEnv* env, jclass caller, jint id, jobject instance) {
	GetFieldTypeCast(env->GetStaticObjectField, env->GetObjectField, id, instance, jshortArray);
}

jintArray GetFieldIntArray(JNIEnv* env, jclass caller, jint id, jobject instance) {
	GetFieldTypeCast(env->GetStaticObjectField, env->GetObjectField, id, instance, jintArray);
}

jlongArray GetFieldLongArray(JNIEnv* env, jclass caller, jint id, jobject instance) {
	GetFieldTypeCast(env->GetStaticObjectField, env->GetObjectField, id, instance, jlongArray);
}

jfloatArray GetFieldFloatArray(JNIEnv* env, jclass caller, jint id, jobject instance) {
	GetFieldTypeCast(env->GetStaticObjectField, env->GetObjectField, id, instance, jfloatArray);
}

jdoubleArray GetFieldDoubleArray(JNIEnv* env, jclass caller, jint id, jobject instance) {
	GetFieldTypeCast(env->GetStaticObjectField, env->GetObjectField, id, instance, jdoubleArray);
}

jobjectArray GetFieldObjectArray(JNIEnv* env, jclass caller, jint id, jobject instance) {
	GetFieldTypeCast(env->GetStaticObjectField, env->GetObjectField, id, instance, jobjectArray);
}

void SetFieldBoolean(JNIEnv* env, jclass caller, jint id, jobject instance, jboolean value) {
	SetFieldType(env->SetStaticBooleanField, env->SetBooleanField, id, instance, value);
}

void SetFieldChar(JNIEnv* env, jclass caller, jint id, jobject instance, jchar value) {
	SetFieldType(env->SetStaticCharField, env->SetCharField, id, instance, value);
}

void SetFieldShort(JNIEnv* env, jclass caller, jint id, jobject instance, jshort value) {
	SetFieldType(env->SetStaticShortField, env->SetShortField, id, instance, value);
}

void SetFieldInt(JNIEnv* env, jclass caller, jint id, jobject instance, jint value) {
	SetFieldType(env->SetStaticIntField, env->SetIntField, id, instance, value);
}

void SetFieldLong(JNIEnv* env, jclass caller, jint id, jobject instance, jlong value) {
	SetFieldType(env->SetStaticLongField, env->SetLongField, id, instance, value);
}

void SetFieldFloat(JNIEnv* env, jclass caller, jint id, jobject instance, jfloat value) {
	SetFieldType(env->SetStaticFloatField, env->SetFloatField, id, instance, value);
}

void SetFieldDouble(JNIEnv* env, jclass caller, jint id, jobject instance, jdouble value) {
	SetFieldType(env->SetStaticDoubleField, env->SetDoubleField, id, instance, value);
}

void SetFieldObject(JNIEnv* env, jclass caller, jint id, jobject instance, jobject value) {
	SetFieldType(env->SetStaticObjectField, env->SetObjectField, id, instance, value);
}

void SetFieldBooleanArray(JNIEnv* env, jclass caller, jint id, jobject instance, jbooleanArray value) {
	SetFieldType(env->SetStaticObjectField, env->SetObjectField, id, instance, value);
}

void SetFieldCharArray(JNIEnv* env, jclass caller, jint id, jobject instance, jcharArray value) {
	SetFieldType(env->SetStaticObjectField, env->SetObjectField, id, instance, value);
}

void SetFieldShortArray(JNIEnv* env, jclass caller, jint id, jobject instance, jshortArray value) {
	SetFieldType(env->SetStaticObjectField, env->SetObjectField, id, instance, value);
}

void SetFieldIntArray(JNIEnv* env, jclass caller, jint id, jobject instance, jintArray value) {
	SetFieldType(env->SetStaticObjectField, env->SetObjectField, id, instance, value);
}

void SetFieldLongArray(JNIEnv* env, jclass caller, jint id, jobject instance, jlongArray value) {
	SetFieldType(env->SetStaticObjectField, env->SetObjectField, id, instance, value);
}

void SetFieldFloatArray(JNIEnv* env, jclass caller, jint id, jobject instance, jfloatArray value) {
	SetFieldType(env->SetStaticObjectField, env->SetObjectField, id, instance, value);
}

void SetFieldDoubleArray(JNIEnv* env, jclass caller, jint id, jobject instance, jdoubleArray value) {
	SetFieldType(env->SetStaticObjectField, env->SetObjectField, id, instance, value);
}

void SetFieldObjectArray(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray value) {
	SetFieldType(env->SetStaticObjectField, env->SetObjectField, id, instance, value);
}

// todo
void UnknownInvoke(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray value) {
	InvokeMethodVoid(env, caller, id, instance, value);
}

jobject InvokeConstructor(JNIEnv* env, jclass caller, jint id, jclass cls, jobjectArray params) {
	if (constructors.count(id)) {
		constructor con = constructors[id];
		return env->NewObject(cls, con.mid, params);
	}
	else {
		std::cout << "Attempted to call constructor that does not exist (" << id << ")" << std::endl;
	}
	return NULL;
}

jbyte InvokeMethodByte(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params) {
	CallMethod(env->CallStaticByteMethod, env->CallByteMethod, id, params, instance);
}

jbyteArray InvokeMethodByteArray(JNIEnv* env, jclass caller, jint id, jobject instance, jobjectArray params) {
	CallMethodCast(env->CallStaticObjectMethod, env->CallObjectMethod, id, params, instance, jbyteArray);
}

jbyte GetFieldByte(JNIEnv* env, jclass caller, jint id, jobject instance) {
	GetFieldType(env->GetStaticByteField, env->GetByteField, id, instance);
}

void SetFieldByte(JNIEnv* env, jclass caller, jint id, jobject instance, jbyte value) {
	SetFieldType(env->SetStaticByteField, env->SetByteField, id, instance, value);
}

jbyteArray GetFieldByteArray(JNIEnv* env, jclass caller, jint id, jobject instance) {
	GetFieldTypeCast(env->GetStaticObjectField, env->GetObjectField, id, instance, jbyteArray);
}

void SetFieldByteArray(JNIEnv* env, jclass caller, jint id, jobject instance, jbyteArray value) {
	SetFieldType(env->SetStaticObjectField, env->SetObjectField, id, instance, value);
}

jstring GetFieldName(JNIEnv* env, jclass caller, jint id) {
	if (fields.count(id)) {
		std::cout << "GetFieldName called with id: " << id << std::endl;
		field fd = fields[id];
		return fd.name;
	}
	else {
		std::cout << "Attempted to get field that does not exist (" << id << ")" << std::endl;
	}
}

jstring GetMethodName(JNIEnv* env, jclass caller, jint id) {
	if (methods.count(id)) {
		std::cout << "GetMethodName called with id: " << id << std::endl;
		method md = methods[id];
		return md.name;
	}
	else {
		std::cout << "Attempted to get method that does not exist (" << id << ")" << std::endl;
	}
}