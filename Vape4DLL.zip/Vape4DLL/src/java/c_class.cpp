#include "c_class.h"

void RegisterEvent(JNIEnv* env, jclass caller, jclass clazz, jint busID) {

	static jclass clsMap = env->FindClass("java/util/Map");
	static jmethodID midMapPut = env->GetMethodID(clsMap, "put", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;");

	static jclass clsEvent;
	static jclass clsListenerList;
	static jclass clsEventPriority;

	static jmethodID midGetListenerList;
	static jmethodID midRegister;

	int version = 23;

	if (version < 14) {

		// Classes:
		// Lcpw/mods/fml/common/eventhandler/Event;
		// Lcpw/mods/fml/common/eventhandler/ListenerList;
		// Lcpw/mods/fml/common/eventhandler/EventPriority;
		// MethodIDs:
		// ()Lcpw/mods/fml/common/eventhandler/ListenerList;
		// (ILcpw/mods/fml/common/eventhandler/EventPriority;Lcpw/mods/fml/common/eventhandler/IEventListener;)V

		clsEvent = env->FindClass("Lcpw/mods/fml/common/eventhandler/Event;");
		clsListenerList = env->FindClass("Lcpw/mods/fml/common/eventhandler/ListenerList;");
		clsEventPriority = env->FindClass("Lcpw/mods/fml/common/eventhandler/EventPriority;");

		midGetListenerList = env->GetMethodID(clsEvent, "getListenerList", "()Lcpw/mods/fml/common/eventhandler/ListenerList;");
		midRegister = env->GetMethodID(clsListenerList, "register", "(ILcpw/mods/fml/common/eventhandler/EventPriority;Lcpw/mods/fml/common/eventhandler/IEventListener;)V");
	}
	else if (version < 26) {

		// Classes:
		// Lnet/minecraftforge/fml/common/eventhandler/Event;
		// Lnet/minecraftforge/fml/common/eventhandler/ListenerList;
		// Lnet/minecraftforge/fml/common/eventhandler/EventPriority;
		// MethodIDs:
		// ()Lnet/minecraftforge/fml/common/eventhandler/ListenerList;
		// (ILnet/minecraftforge/fml/common/eventhandler/EventPriority;Lnet/minecraftforge/fml/common/eventhandler/IEventListener;)V

		clsEvent = env->FindClass("Lnet/minecraftforge/fml/common/eventhandler/Event;");
		clsListenerList = env->FindClass("Lnet/minecraftforge/fml/common/eventhandler/ListenerList;");
		clsEventPriority = env->FindClass("Lnet/minecraftforge/fml/common/eventhandler/EventPriority;");

		midGetListenerList = env->GetMethodID(clsEvent, "getListenerList", "()Lnet/minecraftforge/fml/common/eventhandler/ListenerList;");
		midRegister = env->GetMethodID(clsListenerList, "register", "(ILnet/minecraftforge/fml/common/eventhandler/EventPriority;Lnet/minecraftforge/fml/common/eventhandler/IEventListener;)V");
	}
	else {

		// Classes:
		// Lnet/minecraftforge/eventbus/api/Event;
		// Lnet/minecraftforge/eventbus/ListenerList;
		// Lnet/minecraftforge/eventbus/api/EventPriority;
		// MethodIDs:
		// ()Lnet/minecraftforge/eventbus/ListenerList;
		// (ILnet/minecraftforge/eventbus/api/EventPriority;Lnet/minecraftforge/eventbus/api/IEventListener;)V

		clsEvent = env->FindClass("Lnet/minecraftforge/eventbus/api/Event;");
		clsListenerList = env->FindClass("Lnet/minecraftforge/eventbus/ListenerList;");
		clsEventPriority = env->FindClass("Lnet/minecraftforge/eventbus/api/EventPriority;");

		midGetListenerList = env->GetMethodID(clsEvent, "getListenerList", "()Lnet/minecraftforge/eventbus/ListenerList;");
		midRegister = env->GetMethodID(clsListenerList, "register", "(ILnet/minecraftforge/eventbus/api/EventPriority;Lnet/minecraftforge/eventbus/api/IEventListener;)V");
	}



}