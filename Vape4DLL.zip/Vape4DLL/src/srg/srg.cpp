#include "srg.h"

#include <vector>
#include <iostream>
#include <sstream>
#include <curl/curl.h>
#include "../zip/zip.h"
#include "../json/json.h"

std::vector<std::string> split_string(std::string text, char delimiter) {
	std::vector<std::string> tokens;
	size_t start = 0, end = 0;
	while ((end = text.find(delimiter, start)) != std::string::npos) {
		if (end != start) {
			tokens.push_back(text.substr(start, end - start));
		}
		start = end + 1;
	}
	if (end != start) {
		tokens.push_back(text.substr(start));
	}
	return tokens;
}

void SRG::Init()
{
	std::istringstream lines(this->joined);
	std::string current_line;

	while (getline(lines, current_line))
	{
		std::string type = current_line.substr(0, 2);
		current_line.erase(0, 4);
		std::vector<std::string> split = split_string(current_line, ' ');
		if (type != "PK") {
			if (type == "FD") {
				std::string joined_obf = split[0];
				std::string obf_class = joined_obf.substr(0, joined_obf.find_last_of("/"));
				joined_obf.erase(0, obf_class.length() + 1);
				std::string obf_name = joined_obf;
				std::string joined_deobf = split[1];
				std::string deobf_class = joined_deobf.substr(0, joined_deobf.find_last_of("/"));
				joined_deobf.erase(0, deobf_class.length() + 1);
				std::string deobf_name = joined_deobf;
				field_mappings[obf_class][obf_name] = deobf_name;

			}
			if (type == "MD") {
				std::string joined_obf = split[0];
				std::string obf_class = joined_obf.substr(0, joined_obf.find_last_of("/"));
				joined_obf.erase(0, obf_class.length() + 1);
				std::string obf_name = joined_obf;
				std::string obf_desc = split[1];
				std::string joined_deobf = split[2];
				std::string deobf_class = joined_deobf.substr(0, joined_deobf.find_last_of("/"));
				joined_deobf.erase(0, deobf_class.length() + 1);
				std::string deobf_name = joined_deobf;
				std::string deobf_desc = split[3];
				method_mappings[obf_class][obf_name][obf_desc] = deobf_name;
			}
			if (type == "CL") {
				std::string obf_class = split[0];
				std::string deobf_class = split[1];
				class_mappings[obf_class] = deobf_class;
				class_mappings_reversed[deobf_class] = obf_class;
			}
		}
	}

	lines = std::istringstream(this->fields);
	while (getline(lines, current_line))
	{
		std::vector<std::string> split = split_string(current_line, ',');
		std::string obf_name = split[0];
		std::string deobf_name = split[1];
		mcp_field_mappings[obf_name] = deobf_name;
	}

	lines = std::istringstream(this->methods);
	while (getline(lines, current_line))
	{
		std::vector<std::string> split = split_string(current_line, ',');
		std::string obf_name = split[0];
		std::string deobf_name = split[1];
		mcp_method_mappings[obf_name] = deobf_name;
	}
}

static size_t WriteCallback(void* contents, size_t size, size_t nmemb, void* userp)
{
	((std::string*)userp)->append((char*)contents, size * nmemb);
	return size * nmemb;
}


// todo add offline loading.
void SRG::Load(std::string version) {

	std::cout << "Getting mappings..." << std::endl;

	size_t mappings_size;
	char* mappings_resource = (char*)resources.Load(IDR_MAPPINGS, &mappings_size);
	if (mappings_resource == nullptr) {
		std::cout << "resource is null." << std::endl;
		return;
	}

	zip_t* mappings_zip = zip_stream_open(mappings_resource, mappings_size, 0, 'r');
	if (mappings_zip == nullptr) {
		std::cout << "zip is null." << std::endl;
		return;
	}
	{
		void* joined_buf = NULL;
		size_t joined_buf_size;

		zip_entry_open(mappings_zip, std::string(version + "/joined.srg").c_str());
		{
			zip_entry_read(mappings_zip, &joined_buf, &joined_buf_size);
		}
		zip_entry_close(mappings_zip);

		this->joined = std::string((char*)joined_buf);

		void* fields_buf = NULL;
		size_t fields_buf_size;
		zip_entry_open(mappings_zip, std::string(version + "/fields.csv").c_str());
		{
			zip_entry_read(mappings_zip, &fields_buf, &fields_buf_size);
		}
		zip_entry_close(mappings_zip);

		this->fields = std::string((char*)fields_buf);

		void* methods_buf = NULL;
		size_t methods_buf_size;
		zip_entry_open(mappings_zip, std::string(version + "/methods.csv").c_str());
		{
			zip_entry_read(mappings_zip, &methods_buf, &methods_buf_size);
		}
		zip_entry_close(mappings_zip);

		this->methods = std::string((char*)methods_buf);

	}
	zip_close(mappings_zip);

	std::cout << "Mappings loaded..." << std::endl;


	
	/*
	CURL* curl;
	CURLcode res;

	std::string versionsUrl = "http://export.mcpbot.bspk.rs/export/versions.json";
	std::string versions_buffer;
	nlohmann::json versions_json;


	curl = curl_easy_init();
	if (curl) {
		curl_easy_setopt(curl, CURLOPT_URL, versionsUrl.c_str());
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, &versions_buffer);
		res = curl_easy_perform(curl);
		curl_easy_cleanup(curl);
		if (res == CURLE_OK) {
			versions_json = nlohmann::json::parse(versions_buffer);
		}
		else {
			MessageBoxA(NULL, "Error", "Failed to get Versions.", 0);
		}
	}


	int stable_version = versions_json[version]["stable"][0].get<int>();

	std::cout << "Getting SRG mappings..." << std::endl;

	std::string srg_buffer;
	std::string srgUrl = R"(http://export.mcpbot.bspk.rs/mcp/)" + version + R"(/mcp-)" + version + R"(-srg.zip)";
	curl = curl_easy_init();
	if (curl) {
		curl_easy_setopt(curl, CURLOPT_URL, srgUrl.c_str());
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, &srg_buffer);
		res = curl_easy_perform(curl);
		curl_easy_cleanup(curl);
		if (res == CURLE_OK) {
			zip_t* srg_zip = zip_stream_open(srg_buffer.c_str(), srg_buffer.size(), 0, 'r');
			{
				void* joined_buf = NULL;
				size_t joined_buf_size;
				zip_entry_open(srg_zip, "joined.srg");
				{
					zip_entry_read(srg_zip, &joined_buf, &joined_buf_size);
				}
				zip_entry_close(srg_zip);

				this->joined = std::string((char*)joined_buf);
			}
		}
		else {
			MessageBoxA(NULL, "Error", "Failed to get SRG mappings.", 0);
		}
	}

	std::cout << "Getting MCP mappings..." << std::endl;

	std::string mcp_buffer;
	std::string stable_string = std::to_string(stable_version);
	std::string mcpUrl = R"(http://export.mcpbot.bspk.rs/mcp_stable/)" + stable_string + R"(-)" + version + R"(/mcp_stable-)" + stable_string + R"(-)" + version + R"(.zip)";
	curl = curl_easy_init();
	if (curl) {
		curl_easy_setopt(curl, CURLOPT_URL, mcpUrl.c_str());
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, &mcp_buffer);
		res = curl_easy_perform(curl);
		curl_easy_cleanup(curl);
		if (res == CURLE_OK) {
			zip_t* mcp_zip = zip_stream_open(mcp_buffer.c_str(), mcp_buffer.size(), 0, 'r');
			{
				void* fields_buf = NULL;
				size_t fields_buf_size;
				zip_entry_open(mcp_zip, "fields.csv");
				{
					zip_entry_read(mcp_zip, &fields_buf, &fields_buf_size);
				}
				zip_entry_close(mcp_zip);

				this->fields = std::string((char*)fields_buf);

				void* methods_buf = NULL;
				size_t methods_buf_size;
				zip_entry_open(mcp_zip, "methods.csv");
				{
					zip_entry_read(mcp_zip, &methods_buf, &methods_buf_size);
				}
				zip_entry_close(mcp_zip);

				this->methods = std::string((char*)methods_buf);
			}
		}
		else {
			MessageBoxA(NULL, "Error", "Failed to get MCP mappings.", 0);
		}
	}*/

	std::cout << "Loading mappings..." << std::endl;
	

	Init();
}

/*
	Returns the mcp name of the class.
*/
std::string SRG::GetUnobfuscatedClassName(std::string obfuscated_name)
{
	return this->class_mappings[obfuscated_name];
}

/*
	Returns the ProGuard name of the class
*/
std::string SRG::GetObfuscatedClassName(std::string unobfuscated_class_name)
{
	return this->class_mappings_reversed[unobfuscated_class_name];
}

/*
	Returns the field_ name of the field
*/
auto SRG::GetSRGFieldName(const std::string obfuscated_class, std::string obfuscated_name) -> std::string
{
	auto fields = this->field_mappings[obfuscated_class];
	return fields[obfuscated_name];
}

/*
	Returns the mapped name of the field
*/
std::string SRG::GetMCPFieldName(std::string srg_name)
{
	return mcp_field_mappings[srg_name];
}

/*
	Returns the func_ name of the method
*/
auto SRG::GetSRGMethodName(const std::string obfuscated_class, std::string obfuscated_name, std::string obfusated_descriptor) -> std::string
{
	auto methods = this->method_mappings[obfuscated_class];
	return methods[obfuscated_name][obfusated_descriptor];
}

/*
	Returns the mapped name of the method
*/
std::string SRG::GetMCPMethodName(std::string srg_name)
{
	return mcp_method_mappings[srg_name];
}

SRG srg;