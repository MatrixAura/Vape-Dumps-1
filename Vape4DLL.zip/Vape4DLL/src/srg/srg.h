#pragma once

#include <string>
#include <map>
#include "../resources/resources.h"

class SRG
{
private:
	std::string joined;
	std::string fields;
	std::string methods;
	std::map<std::string, std::string> class_mappings;
	std::map<std::string, std::string> class_mappings_reversed;
	std::map<std::string, std::string> mcp_field_mappings;
	std::map<std::string, std::string> mcp_method_mappings;
	std::map<std::string, std::map<std::string, std::string>> field_mappings;
	std::map<std::string, std::map<std::string, std::map<std::string, std::string>>> method_mappings;
private:
	auto Init() -> void;
public:
	void Load(std::string version);
	std::string GetUnobfuscatedClassName(std::string obfuscated_name);	     // MCP
	std::string GetObfuscatedClassName(std::string unobfuscated_class_name); // ProGuard
	//std::string GetUnobfuscatedDescriptor(std::string obfuscated_descriptor) const;
	std::string GetSRGFieldName(std::string obfuscated_class, std::string obfuscated_name);
	std::string GetMCPFieldName(std::string srg_name);
	std::string GetSRGMethodName(std::string obfuscated_class, std::string obfuscated_name, std::string description);
	std::string GetMCPMethodName(std::string srg_name);
};
extern SRG srg;